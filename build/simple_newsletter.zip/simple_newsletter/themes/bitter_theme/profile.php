<?php defined('C5_EXECUTE') or die("Access Denied."); ?>
<?php $view->inc('elements/header.php'); ?>

<div class="ccm-page-profile">
    <?php echo $innerContent ?>
</div>

<?php $view->inc('elements/footer.php'); ?>
